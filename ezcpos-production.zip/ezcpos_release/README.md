# EZC POS — Production Development Baseline

A single repository for EZC POS: Django/DRF backend, Flutter mobile client, Next.js web client, PostgreSQL, Docker and GitHub Codespaces.

## Development target
- Flutter: 3.47.0 stable / Dart compatible with that SDK
- Python: 3.12+
- Django: 5.2 LTS line
- PostgreSQL: 16+
- Node: 22+

## Codespaces
Open the repository in GitHub Codespaces. The `.devcontainer` installs the required development tools. Then:

```bash
./scripts/setup.sh
./scripts/test.sh
./scripts/dev.sh
```

Backend: `http://127.0.0.1:8000/`
Web: `http://127.0.0.1:3000/`

## Backend quickstart
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py test
python manage.py runserver
```

## Flutter
The mobile app is intentionally kept compatible with Flutter 3.47 stable. Run:
```bash
cd mobile
flutter pub get
flutter test
flutter analyze
```

## Production note
This package is a tested development baseline, not a claim that every physical device, payment provider, barcode scanner, offline-sync edge case, App Store/Play Store process, and production infrastructure has been certified. Those integrations require environment-specific verification.
