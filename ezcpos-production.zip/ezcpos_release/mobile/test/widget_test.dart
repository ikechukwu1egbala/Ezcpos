import 'package:flutter_test/flutter_test.dart';
import 'package:ezcpos_mobile/main.dart';
void main(){testWidgets('EZC home loads',(tester)async{await tester.pumpWidget(const EZCApp());expect(find.text('EZC POS'),findsOneWidget);expect(find.text('Dashboard'),findsOneWidget);});}
