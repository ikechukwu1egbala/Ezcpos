from django.contrib import admin
from django.urls import include,path
from rest_framework_simplejwt.views import TokenObtainPairView,TokenRefreshView
urlpatterns=[path('admin/',admin.site.urls),path('',include('core.urls')),path('api/auth/token/',TokenObtainPairView.as_view()),path('api/auth/token/refresh/',TokenRefreshView.as_view()),path('api/users/',include('users.urls')),path('api/pos/',include('pos.urls')),path('api/inventory/',include('inventory.urls')),path('api/payments/',include('payments.urls')),path('api/expenses/',include('expenses.urls')),path('api/reports/',include('reports.urls'))]
