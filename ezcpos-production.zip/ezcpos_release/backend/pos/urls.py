from django.urls import path
from .views import products,sales
urlpatterns=[path('products/',products),path('sales/',sales)]
