from decimal import Decimal
from django.test import TestCase
from django.contrib.auth import get_user_model
from users.models import Business
from .models import Product
from inventory.models import InventoryBalance,InventoryMovement
from .services import create_sale
from payments.services import record_payment,record_refund
class PosFlowTests(TestCase):
 def setUp(self):
  self.business=Business.objects.create(name='Test Shop'); self.user=get_user_model().objects.create_user(username='owner',password='pass',business=self.business,role='owner'); self.product=Product.objects.create(business=self.business,name='Rice',selling_price=100,buying_price=80); InventoryBalance.objects.create(product=self.product,quantity=10)
 def test_sale_payment_partial_and_refund(self):
  sale=create_sale(business=self.business,user=self.user,items=[{'product':self.product,'quantity':2}]); self.assertEqual(sale.total,Decimal('200')); self.assertEqual(InventoryBalance.objects.get(product=self.product).quantity,8)
  p=record_payment(sale=sale,amount=100,method='CASH'); self.assertEqual(sale.__class__.objects.get(pk=sale.pk).status,'PARTIAL'); record_payment(sale=sale,amount=100,method='TRANSFER'); self.assertEqual(sale.__class__.objects.get(pk=sale.pk).status,'PAID'); record_refund(payment=p,amount=100); self.assertEqual(sale.__class__.objects.get(pk=sale.pk).status,'PARTIAL')
 def test_overpayment_rejected(self):
  sale=create_sale(business=self.business,user=self.user,items=[{'product':self.product,'quantity':1}])
  with self.assertRaises(ValueError): record_payment(sale=sale,amount=101,method='CASH')
