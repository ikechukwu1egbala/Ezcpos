from django.db import models
class Customer(models.Model):
    business=models.ForeignKey('users.Business',on_delete=models.CASCADE,related_name='customers')
    name=models.CharField(max_length=200); phone=models.CharField(max_length=50,blank=True); address=models.CharField(max_length=300,blank=True)
class Category(models.Model):
    business=models.ForeignKey('users.Business',on_delete=models.CASCADE,related_name='categories'); name=models.CharField(max_length=100)
class Product(models.Model):
    business=models.ForeignKey('users.Business',on_delete=models.CASCADE,related_name='products')
    category=models.ForeignKey(Category,on_delete=models.SET_NULL,null=True,blank=True)
    name=models.CharField(max_length=200); sku=models.CharField(max_length=100,blank=True); barcode=models.CharField(max_length=100,blank=True)
    buying_price=models.DecimalField(max_digits=12,decimal_places=2,default=0); selling_price=models.DecimalField(max_digits=12,decimal_places=2,default=0)
    low_stock_threshold=models.DecimalField(max_digits=12,decimal_places=2,default=0); description=models.TextField(blank=True); recognition_enabled=models.BooleanField(default=False)
class Sale(models.Model):
    STATUS_CHOICES=[('OPEN','Open'),('PAID','Paid'),('PARTIAL','Partial'),('CREDIT','Credit'),('REFUNDED','Refunded')]
    business=models.ForeignKey('users.Business',on_delete=models.CASCADE,related_name='sales'); customer=models.ForeignKey(Customer,on_delete=models.SET_NULL,null=True,blank=True)
    total=models.DecimalField(max_digits=12,decimal_places=2,default=0); status=models.CharField(max_length=20,choices=STATUS_CHOICES,default='OPEN'); created_at=models.DateTimeField(auto_now_add=True)
class SaleItem(models.Model):
    sale=models.ForeignKey(Sale,on_delete=models.CASCADE,related_name='items'); product=models.ForeignKey(Product,on_delete=models.PROTECT); quantity=models.DecimalField(max_digits=12,decimal_places=3); unit_price=models.DecimalField(max_digits=12,decimal_places=2)
    @property
    def line_total(self): return self.quantity*self.unit_price
