from decimal import Decimal
from django.db import transaction
from .models import Sale,SaleItem
from inventory.models import InventoryBalance,InventoryMovement
@transaction.atomic
def create_sale(*,business,user,items,customer=None):
    sale=Sale.objects.create(business=business,customer=customer,status='OPEN')
    total=Decimal('0')
    for item in items:
        product=item['product']; qty=Decimal(str(item['quantity'])); price=Decimal(str(item.get('unit_price',product.selling_price)))
        balance=InventoryBalance.objects.select_for_update().get_or_create(product=product,defaults={'quantity':0})[0]
        if balance.quantity < qty: raise ValueError(f'Insufficient stock for {product.name}')
        SaleItem.objects.create(sale=sale,product=product,quantity=qty,unit_price=price)
        balance.quantity-=qty; balance.save(update_fields=['quantity'])
        InventoryMovement.objects.create(product=product,movement_type='SALE',quantity=-qty,reference=f'SALE-{sale.id}')
        total += qty*price
    sale.total=total; sale.save(update_fields=['total']); return sale
