from django.contrib import admin
from .models import Customer,Category,Product,Sale,SaleItem
admin.site.register([Customer,Category,Product,Sale,SaleItem])
