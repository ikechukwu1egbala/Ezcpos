from rest_framework.decorators import api_view,permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Product,Sale
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def products(request): return Response(list(Product.objects.filter(business=request.user.business).values('id','name','sku','barcode','selling_price','buying_price')))
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def sales(request): return Response(list(Sale.objects.filter(business=request.user.business).values('id','total','status','created_at')))
