from django.db import models
class InventoryBalance(models.Model):
    product=models.OneToOneField('pos.Product',on_delete=models.CASCADE,related_name='inventory'); quantity=models.DecimalField(max_digits=14,decimal_places=3,default=0)
class InventoryMovement(models.Model):
    TYPES=[('SALE','Sale'),('RESTOCK','Restock'),('RETURN','Return'),('ADJUSTMENT','Adjustment')]
    product=models.ForeignKey('pos.Product',on_delete=models.CASCADE,related_name='movements'); movement_type=models.CharField(max_length=20,choices=TYPES); quantity=models.DecimalField(max_digits=14,decimal_places=3); reference=models.CharField(max_length=100,blank=True); created_at=models.DateTimeField(auto_now_add=True)
