from django.contrib import admin
from .models import Business,Branch,User
admin.site.register([Business,Branch,User])
