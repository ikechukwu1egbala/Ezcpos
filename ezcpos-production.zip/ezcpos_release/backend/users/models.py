from django.contrib.auth.models import AbstractUser
from django.db import models
class Business(models.Model):
    name=models.CharField(max_length=200)
    created_at=models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.name
class Branch(models.Model):
    business=models.ForeignKey(Business,on_delete=models.CASCADE,related_name='branches')
    name=models.CharField(max_length=200)
    address=models.CharField(max_length=300,blank=True)
class User(AbstractUser):
    business=models.ForeignKey(Business,on_delete=models.CASCADE,null=True,blank=True,related_name='users')
    role=models.CharField(max_length=30,default='staff')
