from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
@login_required
def daily(request): return JsonResponse({'status':'ok'})
