from django.db import models
class Expense(models.Model):
    business=models.ForeignKey('users.Business',on_delete=models.CASCADE,related_name='expenses'); title=models.CharField(max_length=200); amount=models.DecimalField(max_digits=12,decimal_places=2); created_at=models.DateTimeField(auto_now_add=True)
