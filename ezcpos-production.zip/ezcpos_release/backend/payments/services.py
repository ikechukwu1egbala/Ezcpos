from decimal import Decimal
from django.db import transaction
from .models import Payment,Refund
@transaction.atomic
def record_payment(*,sale,amount,method):
    amount=Decimal(str(amount)); paid=sum((p.amount for p in sale.payments.all()),Decimal('0')); refunded=sum((r.amount for p in sale.payments.all() for r in p.refunds.all()),Decimal('0'))
    if amount<=0 or paid-refunded+amount>sale.total: raise ValueError('Payment exceeds outstanding balance')
    p=Payment.objects.create(sale=sale,amount=amount,method=method); new=paid-refunded+amount
    sale.status='PAID' if new>=sale.total else 'PARTIAL'; sale.save(update_fields=['status']); return p
@transaction.atomic
def record_refund(*,payment,amount):
    amount=Decimal(str(amount)); refunded=sum((r.amount for r in payment.refunds.all()),Decimal('0'))
    if amount<=0 or refunded+amount>payment.amount: raise ValueError('Refund exceeds payment amount')
    r=Refund.objects.create(payment=payment,amount=amount)
    sale=payment.sale; net=sum((p.amount for p in sale.payments.all()),Decimal('0'))-sum((x.amount for p in sale.payments.all() for x in p.refunds.all()),Decimal('0'))
    sale.status='REFUNDED' if net<=0 else ('PARTIAL' if net<sale.total else 'PAID'); sale.save(update_fields=['status']); return r
