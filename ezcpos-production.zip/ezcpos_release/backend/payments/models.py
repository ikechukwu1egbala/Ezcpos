from django.db import models
class Payment(models.Model):
    METHODS=[('CASH','Cash'),('CARD','Card'),('TRANSFER','Transfer')]
    sale=models.ForeignKey('pos.Sale',on_delete=models.CASCADE,related_name='payments'); amount=models.DecimalField(max_digits=12,decimal_places=2); method=models.CharField(max_length=20,choices=METHODS); created_at=models.DateTimeField(auto_now_add=True)
class Refund(models.Model):
    payment=models.ForeignKey(Payment,on_delete=models.CASCADE,related_name='refunds'); amount=models.DecimalField(max_digits=12,decimal_places=2); created_at=models.DateTimeField(auto_now_add=True)
