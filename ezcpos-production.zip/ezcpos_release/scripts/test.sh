#!/usr/bin/env bash
set -euo pipefail
backend/.venv/bin/python backend/manage.py check
backend/.venv/bin/python backend/manage.py test
if command -v npm >/dev/null; then (cd web && npm run build); fi
if command -v flutter >/dev/null; then (cd mobile && flutter analyze && flutter test); fi
echo 'All available test suites completed.'
