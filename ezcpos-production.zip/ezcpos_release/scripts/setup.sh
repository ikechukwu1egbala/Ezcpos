#!/usr/bin/env bash
set -euo pipefail
python3 -m venv backend/.venv
backend/.venv/bin/pip install -q -r backend/requirements.txt
backend/.venv/bin/python backend/manage.py makemigrations users pos inventory payments expenses reports
backend/.venv/bin/python backend/manage.py migrate
if command -v npm >/dev/null; then (cd web && npm install); fi
if command -v flutter >/dev/null; then (cd mobile && flutter pub get); fi
echo 'EZC POS setup complete.'
