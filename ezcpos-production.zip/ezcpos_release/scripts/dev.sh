#!/usr/bin/env bash
set -euo pipefail
backend/.venv/bin/python backend/manage.py runserver 0.0.0.0:8000 &
(cd web && npm run dev -- --hostname 0.0.0.0) &
wait
