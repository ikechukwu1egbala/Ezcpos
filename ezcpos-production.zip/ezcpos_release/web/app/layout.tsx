import React from 'react';
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body style={{fontFamily:'sans-serif',margin:40}}>{children}</body></html>}
